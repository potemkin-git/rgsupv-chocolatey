Guide d'utilisation pour les utilisateurs Windows
=====================================

A Propos de RG Supervision

        RG Supervision est l’outil universel pour superviser vos serveurs.

        Nous offrons un service client complet, un support e-mail illimité, les
        mises à jour gratuites et un paiement au plus juste. L’agent se
        télécharge en moins d’1 minute et ne nécessite aucune formation
        particulière, ni infrastructure.

        Pour plus d'informations, rendez-vous sur
        https://www.rgsystem.com


Configuration Requise

        RG Supervision ne nécessite que Microsoft Visual C++ 2008
        Redistributable Package (x86). Cet outils est disponible dans le dossier
        Tools/, ou peut être téléchargé à l'adresse suivante :

            http://www.microsoft.com/download/en/details.aspx?id=29


Démarrage Rapide

        Pour installer RG Supervision et enregistrer votre agent, il vous suffit
        de :

        1. Simplement démarrer RG-Setup et de suivre les instructions affichées
           à l'écran

        2. Si une erreur de type "side-by-side assembly" (ou "cote-à-côte")
           arrive, il faudra installer MSVCRT (Voir la partie Configuration
           requise), et recommencer la première étape


Le Binaire RG Supervision

        Sous Windows, RG Supervision utilise un binaire de type hybride : La
        console et l'interface utilisateur sont combinées pour simplifier la vie
        des utilisateurs. Les avantages des applications monolithiques offrent
        beaucoup d'avantages :

            - Installation au travers d'une interface utilisateur sympa
            - Configuration réseau
            - Tests réseau
            - Contrôle de l'icone de notification
            - Le service Windows
            - Contrôle par la ligne de commande
            - Désinstallation

            Sous Windows, un binaire ne peut pas être une interface utilisateur
            ET une console. C'est pourquoi l'application RG Supervision n'est
            pas verbeuse du tout lorsqu'elle est utilisée en ligne de commande.
            Mais vous pouvez consulter les potentiels messages grâce aux
            événements Windows.


Ligne de Commande RG Supervision

    1. Introduction

        Il est possible d'entièrement contrôller RG Supervision en utilisant la
        ligne de commande pour du déploiement massif, pour gérer le statut de
        maintenance de la machine (pour des tâches planifiées), gérer la
        configuration réseau et bien plus encore.

        Toutes les directives RG Supervision doivent être précédées d'une
        directive "action", par exemple :

            RG_Supervision.exe --action une-action --option1 valeur1

        Toutes les options de la ligne de commande doivent être entourées de
        guillemets (") si elles contiennent des espaces :

            RG_Supervision.exe --option1 "une option avec des espaces"

    2. Directives Disponibles (--action [directive])

        register                Cette directive mène à un enregistrement ET une
                                installation. Elle doit être couplée avec au
                                moins les options --login, --password et --node.

        reregister              Cette directive mène à un ré-enregistrement ET
                                une installation. Elle doit être couplée avec au
                                moins les options --login, --password et
                                --idagent.

        uninstall-console       Cette directive désinstalle RG Supervision.

        networktest             Cette directive effectue un test réseau pour
                                s'assurer de la bonne configuration. Ce test
                                garantie que l'agent est capable de communiquer
                                avec les serveurs distants.

        proxy-settings          Cette directive est utilisée pour configurer les
                                options proxy. Elle doit être couplée avec au
                                moins les options --proxy-enabled et
                                --proxy-host.

        disable-alerts          Désactive les alertes pour 60 minutes (valeur
                                par defaut). Vous pouvez spécifier un temps plus
                                précis avec l'option --timeout. Si une valeur
                                invalide est saisie, "60 minutes" sera alors
                                utilisé.

        enable-alerts           Active les alertes précédemment désactivées. Si
                                les alertes n'avaient pas été désactivées, cette
                                directive ne fait rien.


    3. Options des Directives

        --login                 Le login utilisé pour enregistrer ou
                                ré-enregistrer un agent.

        --password              Le mot de passe associé au --login.

        --node                  Le nom du noeud à utiliser (ou créer). Il est
                                aussi possible de cibler directement un noeud
                                en utilisant #<id> (exemple : #1337)

        --idagent               L'ID de l'agent à ré-enregistrer.
                                Exemple : BU21-Z4-L4

        --machine               Le nom que portera votre agent dans le
                                dashboard. Si rien n'est précisé, le nom de la
                                machine sera utilisé.

        --install-path          Le chemin d'installation utilisé par RG
                                Supervision lors d'une installation. Si rien
                                n'est précisé, le répertoire Program Files
                                proposé par le système sera utilisé.

        --remote-ctrl           Option dépréciée. 

        --timeout               Le temps que les alertes devraient être
                                désactivées.

        --proxy-enabled         Active la configuration du proxy à utiliser par
                                l'agent RG Supervision. Options disponibles :
                                Yes, No. Defaut : No.

        --proxy-host            L'hôte proxy. Exemple: proxy1.url.com

        --proxy-port            Le port du proxy. Example: 8080. Defaut: 3128.

        --proxy-user            L'utilisateur proxy à utiliser si une
                                authentification est requise.

        --proxy-pass            Le mot de passe de l'utilisateur proxy si une
                                authentification est requise.

        --proxy-type            Le type de proxy à utiliser. Options disponibles
                                : http, socks5, relay. Defaut: socks5.

        --ignore-ssl-errors     Cette option vous permet d'ignorer les erreurs
                                SSL qui pourraient survenir lors d'une connexion
                                aux serveurs.


    4. Notes

        Comme expliqué dans le chapitre d'introduction, RG Supervision est un
        binaire de type "GUI", ce qui implique que le processus n'est pas
        capable d'écrire dans une console, même si l'application est démarrée
        depuis la console. Une méthode simple pour savoir si l'opération s'est
        bien passée est de regarder la valeur de retour du processus.

            - 0 Succès
            - 1 Erreur de directive (Authentification, Installation, Réseau ...)
            - 2 Erreur d'un paramètre d'entrée (Un paramètre requis a été
                oublié)

        Pour récupérer la valeur de retour d'un processus Windows, vous devriez
        utiliser un script batch comme suit :

            RG_Supervision.exe --action enable-alerts
            echo %ERRORLEVEL%

    5. Exemples

        1. Installer un agent avec le nom de machine Windows, dans le répertoire
           par defaut

            RG_Supervision.exe --action register --login user@example.com     \
            --password SomePassword --node "Node name"

        2. Installer un agent avec le nom de machine Windows, dans le répertoire
           par defaut, avec une configuration proxy particulière

            RG_Supervision.exe --action register --login user@example.com     \
            --password SomePassword --node "Node name" --proxy-enabled Yes    \
            --proxy-host proxy1.example.com --proxy-port 3129 --proxy-user    \
            user1 --proxy-pass pass1 --proxy-type http

        3. Ré-enregistrer un agent

            RG_Supervision.exe --action reregister --login user@example.com   \
            --password SomePass --idagent BU21-Z4-L4 --install-path           \
            "D:\RG-Supervision"

        4. Désinstaller un agent

            RG_Supervision.exe --action uninstall-console

        5. Effectuer un test de réseau simple, en utilisant la configuration
           réseau actuelle

            RG_Supervision.exe --action networktest

        6. Effectuer un test de réseau simple, en utilisant une configuration
           réseau particulière

            RG_Supervision.exe --action networktest --proxy-enabled Yes       \
            --proxy-host proxy1.example.com --proxy-port 3129 --proxy-user    \
            user1 --proxy-pass pass1 --proxy-type http

        7. Désactiver les alertes pendant 10 minutes pour cet agent (par exemple
           à cause d'une tâche pouvant perturber les indicateurs de l'agent,
           comme une sauvegarde)

            RG_Supervision.exe --action disable-alerts --timeout 10

        8. Réactiver les alertes

            RG_Supervision.exe --action enable-alerts


        Note: Le dossier d'installation de RG Supervision n'est pas enregistré
        dans la variable d'environnement %PATH%. Vous devez executer ces
        commandes depuis le repertoire d'installation, ou bien ajouter le
        répertoire d'installation à la variable %PATH%.

Notes

        L'agent communique uniquement sur le port 443, en TCP, en sortie, dans
        un tunnel SSL. L'adresse distante est lisa.rg-supervision.com.


================================================================================
COPYRIGHT (c) Since 2008 - RG System All rights reserved.
