RG Supervision for Windows User Guide
=====================================

About RG Supervision

        First French solution which automatically monitors your computer
        parks in SaaS.

        RG Supervision is an innovative tool that works in SaaS (software
        family administered by the Internet, without installation at home!).
        Our subscription service gives you as professional advantages as the 
        softwares currently on the market for an affordable monthly cost and
        with a simplicity of implementation to none!

        For more informations, visit
        https://www.rgsystem.com


System Requirements

        RG Supervision only requires the Microsoft Visual C++ 2008
        Redistributable Package (x86). This can be found in Tools/ directory,
        or downloaded at:

            http://www.microsoft.com/download/en/details.aspx?id=29


Quick Start

        To install RG Supervision and register your agent, do the following:

        1. Just start RG-Setup, and follow instructions

        2. If a side-by-side assembly error occurs, please install MSVCRT (See
           System Requirements chapter), and go to first step


RG Supervision Binary

        On Windows, RG Supervision uses an hybrid binary type: Console and GUI
        combined to enhance the user experience. It allows to have a simple
        monolithic file able to do a lot of things:

            - Installation through a user friendly GUI
            - Network configuration
            - Network testing
            - Tray icon control
            - Windows service
            - Command line aware tool
            - Uninstallation

        On Windows, a binary is flagged as GUI or Console, not both. This is
        why RG Supervision is not verbose at all when used through command
        line, but you can retreive any output message through Windows Events.


RG Supervision Command Line

    1. Introduction

        It is possible to fully control RG Supervision using the command line
        for massive deployment, remote alert management (for some planned
        tasks), managing the network configuration and so on.

        Any RG Supervision directives must be wrapped in an "action" directive
        like this:

            RG_Supervision.exe --action some-action --option1 value1

        Every command line option MUST be wrapped in quotes (") if it contains
        a space:

            RG_Supervision.exe --option1 "some option with spaces"

    2. Availables Directives (--action [directive])

        register                This directive implies a registration AND an
                                installation. It must be specified with at least
                                --login, --password and --node.

        reregister              This directive implies a reregistration AND an
                                installation. It must be specified with at least
                                --login, --password and --idagent.

        uninstall-console       This directive uninstalls RG Supervision.

        networktest             This directive performs a networktest to ensure
                                the agent will be able to use the current
                                network configuration to communicate with
                                remotes servers.

        proxy-settings          This directive is used to configure proxy
                                settings. It must be specified with at least
                                --proxy-enabled and --proxy-host.

        disable-alerts          Disable alerts for 60 minutes. Default
                                time is 60 minutes if an invalid value is
                                passed to --timeout.

        enable-alerts           Enable alerts previously disabled. If nothing
                                has been disabled, this command has no effects.


    3. Directives Options

        --login                 The login used to register or reregister an
                                agent.

        --password              The password used to login.

        --node                  The node name to create when registering. It is
                                also possible to aim a node id by
                                using #<id> (example: #1337)

        --idagent               The ID Agent to use when reregistering.
                                Example: BU21-Z4-L4

        --machine               The Agent name to display on RG Supervision
                                dashboard. If nothing is specified, the Windows
                                name is used.

        --install-path          The install path used by RG Supervision when
                                registering or reregistering. This option is not
                                required, and if nothing is specified, the
                                correct Program Files directory is used.

        --remote-ctrl           Deprecated option.

        --timeout               The duration alerts should be remotely disabled.

        --proxy-enabled         Enable the proxy configuration to be used by RG
                                Supervision. Available options: Yes, No.
                                Default: No.

        --proxy-host            The proxy host to use. Example: proxy1.url.com

        --proxy-port            The proxy port to use. Example: 8080. Defaut:
                                3128.

        --proxy-user            The proxy user to use when authentication is
                                required. Default: empty.

        --proxy-pass            The proxy password to use when authentication is
                                required. Default: empty.

        --proxy-type            The proxy type to use. Available options: http,
                                socks5, relay. Default: socks5.

        --ignore-ssl-errors     This option allows you to ignore ssl errors
                                encountered when establishing a connection to the
                                servers.


    4. Notes

        As explained in the Introduction chapter, RG Supervision is a GUI
        binary, this implies there's no way for RG Supervision process to write
        in the console, even if it's started from the console. A simple method
        to know if an operation went good is to retreive the return value of the
        process.

            - 0 Success
            - 1 Directive error (Authentication, Installation, Networking ...)
            - 2 Input error (A required parameter is omitted)

        To retreive the return value of a process on Windows with a GUI binary,
        you should use a batch file like this:

            RG_Supervision.exe --action enable-alerts
            echo %ERRORLEVEL%

    5. Examples

        1. Install an Agent with the Windows machine name, in the default
           Program Files directory

            RG_Supervision.exe --action register --login user@example.com     \
            --password SomePassword --node "Node name"

        2. Install an Agent with the Windows machine name, in the default
           Program Files directory, with proxy settings

            RG_Supervision.exe --action register --login user@example.com     \
            --password SomePassword --node "Node name" --proxy-enabled Yes    \
            --proxy-host proxy1.example.com --proxy-port 3129 --proxy-user    \
            user1 --proxy-pass pass1 --proxy-type http

        3. Recover an Agent

            RG_Supervision.exe --action reregister --login user@example.com   \
            --password SomePass --idagent BU21-Z4-L4 --install-path           \
            "D:\RG-Supervision"

        4. Uninstall an Agent

            RG_Supervision.exe --action uninstall-console

        5. Perform a simple network test, using the current register network
           configuration

            RG_Supervision.exe --action networktest

        6. Perform a simple network test, using custom network configuration

            RG_Supervision.exe --action networktest --proxy-enabled Yes       \
            --proxy-host proxy1.example.com --proxy-port 3129 --proxy-user    \
            user1 --proxy-pass pass1 --proxy-type http

        7. Disable alerts for 10 minutes because of a task than can trig alerts

            RG_Supervision.exe --action disable-alerts --timeout 10

        8. Enable back alerts

            RG_Supervision.exe --action enable-alerts


        Note: RG Supervision installation directory is not registered in the
        %PATH% environnement variable. You have to execute command line from
        the installation directory.

Network Miscellaneous

        The agent uses only port 443 over TCP as an outgoing connection,
        wrapped in an SSL tunnel. The remote peer is lisa.rg-supervision.com.


================================================================================
COPYRIGHT (c) Since 2008 - RG System All rights reserved.
